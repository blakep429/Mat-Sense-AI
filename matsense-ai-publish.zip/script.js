const tabs = document.querySelectorAll(".tab");
const videoUpload = document.querySelector("#videoUpload");
const analyzeButton = document.querySelector("#analyzeButton");
const uploadTitle = document.querySelector("#uploadTitle");
const uploadMeta = document.querySelector("#uploadMeta");
const previewDiscipline = document.querySelector("#previewDiscipline");
const analysisTitle = document.querySelector("#analysisTitle");
const analysisStatus = document.querySelector("#analysisStatus");
const timeline = document.querySelector("#timeline");
const drillList = document.querySelector("#drillList");
const skillLevel = document.querySelector("#skillLevel");
const focusArea = document.querySelector("#focusArea");
const uploadsUsed = document.querySelector("#uploadsUsed");
const usageFill = document.querySelector("#usageFill");
const upgradeButton = document.querySelector("#upgradeButton");
const savePlanButton = document.querySelector("#savePlanButton");
const apiNote = document.querySelector("#apiNote");
const historyList = document.querySelector("#historyList");
const clearHistoryButton = document.querySelector("#clearHistoryButton");

let selectedDiscipline = "Boxing";
let uploadCount = Number(localStorage.getItem("matsense_upload_count") || "0");
let currentAnalysis = null;

const fallbackData = {
  Boxing: {
    scores: [78, 84, 72],
    moments: [
      ["00:14", "Rear hand recovery", "Your right hand returns low after the cross. Bring it back to cheek level before exiting the pocket."],
      ["00:31", "Good jab rhythm", "You doubled the jab before stepping out. Keep that tempo because it interrupts counters cleanly."],
      ["00:52", "Exit angle", "You backed straight up after the combination. Add a small pivot or lateral step after your last punch."]
    ],
    drills: ["3 rounds: jab-cross-pivot with a full guard reset", "2 rounds: slip rope after every three-punch combination", "Film one 60-second shadowboxing round focused only on exits"]
  },
  "Muay Thai": {
    scores: [74, 81, 76],
    moments: [
      ["00:18", "Kick setup", "The low kick lands better when you hide it behind the jab. Right now the hip turn starts before the hand feint."],
      ["00:44", "Check position", "Your checking knee comes up well, but your rear hand drifts away from your temple."],
      ["01:05", "Clinch posture", "Your head drops inside during entry. Keep posture tall and frame before pummeling for control."]
    ],
    drills: ["5 minutes: jab to low kick with delayed hip turn", "3 rounds: check-return-cross on both sides", "Partner drill: tall posture clinch entries with inside frame"]
  },
  "Brazilian Jiu-Jitsu": {
    scores: [71, 79, 68],
    moments: [
      ["00:22", "Hip angle", "Your hips flatten during guard retention. Shrimp earlier and turn to your side before the passer clears your knee line."],
      ["00:47", "Underhook window", "You had space for an underhook as they settled half guard. Reach before they crossface."],
      ["01:16", "Frame discipline", "Your bottom arm reaches over the shoulder. Keep it as a frame across the collarbone to protect your neck."]
    ],
    drills: ["10 reps each side: knee shield recovery to underhook", "3 minutes: hip escape rounds with no hand posting", "Positional sparring: start in half guard and win inside head position"]
  },
  MMA: {
    scores: [76, 77, 74],
    moments: [
      ["00:12", "Level change tell", "Your lead hand drops before the shot. Keep the hand active so the entry looks like a strike first."],
      ["00:36", "Fence exit", "You circled toward their power side. Take the outside step first, then turn your shoulders off the fence."],
      ["01:02", "Combination finish", "After the right hand, your stance squares up. Reset before kicking or entering the clinch."]
    ],
    drills: ["3 rounds: jab to level change without dropping lead hand", "Fence drill: outside step, shoulder turn, underhook recovery", "Flow round: two strikes, stance reset, then entry"]
  }
};

function fallbackAnalysis() {
  const data = fallbackData[selectedDiscipline];
  return {
    discipline: selectedDiscipline,
    focus: focusArea.value,
    skillLevel: skillLevel.value,
    fileName: videoUpload.files[0]?.name || "Sample footage",
    confidence: 82,
    scores: {
      guard: data.scores[0],
      balance: data.scores[1],
      timing: data.scores[2]
    },
    moments: data.moments.map(([time, title, body]) => ({ time, title, body })),
    drills: data.drills,
    source: "Browser fallback"
  };
}

function setUsage(count) {
  uploadCount = Math.min(3, count);
  uploadsUsed.textContent = uploadCount;
  usageFill.style.width = `${(uploadCount / 3) * 100}%`;
  localStorage.setItem("matsense_upload_count", String(uploadCount));
}

function getHistory() {
  return JSON.parse(localStorage.getItem("matsense_history") || "[]");
}

function saveHistory(analysis) {
  const history = getHistory();
  history.unshift({
    id: analysis.id || crypto.randomUUID(),
    date: new Date().toLocaleString(),
    discipline: analysis.discipline,
    focus: analysis.focus,
    fileName: analysis.fileName,
    confidence: analysis.confidence
  });
  localStorage.setItem("matsense_history", JSON.stringify(history.slice(0, 6)));
  renderHistory();
}

function renderHistory() {
  const history = getHistory();
  if (!history.length) {
    historyList.innerHTML = `<div class="history-empty">No saved analysis yet. Upload a clip and run analysis to start the library.</div>`;
    return;
  }

  historyList.innerHTML = history.map((item) => `
    <div class="history-item">
      <div>
        <strong>${item.discipline} - ${item.focus}</strong>
        <span>${item.fileName} · ${item.date}</span>
      </div>
      <span class="confidence-pill">${item.confidence}% confidence</span>
    </div>
  `).join("");
}

function renderAnalysis(analysis = fallbackAnalysis(), isFresh = false) {
  currentAnalysis = analysis;
  document.querySelector("#guardScore").textContent = analysis.scores.guard;
  document.querySelector("#balanceScore").textContent = analysis.scores.balance;
  document.querySelector("#timingScore").textContent = analysis.scores.timing;
  previewDiscipline.textContent = analysis.discipline;
  analysisTitle.textContent = `${analysis.discipline} ${analysis.focus.toLowerCase()}`;
  analysisStatus.textContent = isFresh ? "Analyzed" : "Ready";

  timeline.innerHTML = analysis.moments.map((moment) => `
    <div class="moment">
      <span class="timestamp">${moment.time}</span>
      <div>
        <strong>${moment.title}</strong>
        <p>${moment.body}</p>
      </div>
    </div>
  `).join("");

  drillList.innerHTML = analysis.drills.map((drill) => `<li>${drill}</li>`).join("");
}

async function requestAnalysis() {
  const formData = new FormData();
  const file = videoUpload.files[0];
  if (file) formData.append("video", file);
  formData.append("discipline", selectedDiscipline);
  formData.append("skillLevel", skillLevel.value);
  formData.append("focus", focusArea.value);

  const response = await fetch("/api/analyze", {
    method: "POST",
    body: formData
  });

  if (!response.ok) {
    throw new Error("Analysis failed");
  }

  return response.json();
}

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    tabs.forEach((item) => item.classList.remove("is-active"));
    tab.classList.add("is-active");
    selectedDiscipline = tab.dataset.discipline;
    renderAnalysis(fallbackAnalysis());
    apiNote.textContent = `Ready for ${selectedDiscipline} footage.`;
  });
});

videoUpload.addEventListener("change", () => {
  const file = videoUpload.files[0];
  if (!file) return;

  uploadTitle.textContent = file.name;
  uploadMeta.textContent = `${Math.max(1, Math.round(file.size / 1024 / 1024))} MB selected for ${selectedDiscipline} analysis.`;
});

analyzeButton.addEventListener("click", async () => {
  if (uploadCount >= 3) {
    apiNote.textContent = "Free plan limit reached. Upgrade to continue analyzing this month.";
    document.querySelector("#pricing").scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }

  analyzeButton.textContent = "Uploading and analyzing...";
  analysisStatus.textContent = "Scanning";
  apiNote.textContent = "Sending footage details to the local analysis server.";
  analyzeButton.disabled = true;

  try {
    const analysis = await requestAnalysis();
    setUsage(uploadCount + 1);
    renderAnalysis(analysis, true);
    saveHistory(analysis);
    apiNote.textContent = `${analysis.source}: analysis complete for ${analysis.fileName}.`;
  } catch (error) {
    const analysis = fallbackAnalysis();
    setUsage(uploadCount + 1);
    renderAnalysis(analysis, true);
    saveHistory(analysis);
    apiNote.textContent = "Local server unavailable, so browser fallback analysis was used.";
  } finally {
    analyzeButton.textContent = "Analyze footage";
    analyzeButton.disabled = false;
  }
});

upgradeButton.addEventListener("click", () => {
  document.querySelector("#pricing").scrollIntoView({ behavior: "smooth", block: "center" });
});

savePlanButton.addEventListener("click", () => {
  if (currentAnalysis) saveHistory(currentAnalysis);
  savePlanButton.textContent = "Saved";
  window.setTimeout(() => {
    savePlanButton.textContent = "Save plan";
  }, 1200);
});

clearHistoryButton.addEventListener("click", () => {
  localStorage.removeItem("matsense_history");
  renderHistory();
});

skillLevel.addEventListener("change", () => renderAnalysis(fallbackAnalysis()));
focusArea.addEventListener("change", () => renderAnalysis(fallbackAnalysis()));

setUsage(uploadCount);
renderAnalysis();
renderHistory();
