const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const root = __dirname;
const port = Number(process.env.PORT || 4174);

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".json": "application/json; charset=utf-8"
};

const playbooks = {
  Boxing: {
    scores: { guard: 81, balance: 83, timing: 74 },
    moments: [
      { time: "00:13", title: "Guard return", body: "Your rear hand comes home late after the cross. Reset the hand before you admire the shot." },
      { time: "00:29", title: "Lead foot angle", body: "Your lead foot turns in during pressure. Point it slightly outside so the pivot is available." },
      { time: "00:58", title: "Pressure exit", body: "You move straight back after the exchange. Add a small L-step before the next entry." }
    ],
    drills: ["3 rounds: jab-cross-slip with full guard recovery", "4 sets: cone L-step exits after every combination", "Film 60 seconds of shadowboxing with only jab entries"]
  },
  "Muay Thai": {
    scores: { guard: 77, balance: 82, timing: 79 },
    moments: [
      { time: "00:16", title: "Kick disguise", body: "Your hip loads before the hand feint. Let the jab start first, then turn the kick over." },
      { time: "00:41", title: "Check recovery", body: "The check is sharp, but your stance lands narrow afterward. Step back to shoulder width." },
      { time: "01:07", title: "Clinch entry", body: "You reach before winning head position. Frame first, then swim inside." }
    ],
    drills: ["5 minutes: jab to low kick with late hip turn", "3 rounds: check, return kick, stance reset", "Partner pummel: frame before inside control"]
  },
  "Brazilian Jiu-Jitsu": {
    scores: { guard: 73, balance: 80, timing: 70 },
    moments: [
      { time: "00:21", title: "Knee line", body: "Your knee line gets cleared before your hips turn. Shrimp earlier and recover inside position." },
      { time: "00:45", title: "Underhook timing", body: "There is a small window for the underhook as they settle. Reach before the crossface arrives." },
      { time: "01:14", title: "Frame placement", body: "Your bottom arm reaches too high. Keep the frame across the collarbone and protect your neck." }
    ],
    drills: ["10 reps each side: knee shield to underhook", "3-minute rounds: hip escape without posting", "Positional sparring: half guard, win inside head position"]
  },
  MMA: {
    scores: { guard: 78, balance: 78, timing: 76 },
    moments: [
      { time: "00:11", title: "Shot tell", body: "Your lead hand drops before the level change. Keep it active so the entry looks like a strike." },
      { time: "00:37", title: "Fence turn", body: "You circle toward their power side. Take the outside step and turn your shoulders first." },
      { time: "01:01", title: "Stance reset", body: "After the right hand your stance squares up. Reset before kicking or changing levels." }
    ],
    drills: ["3 rounds: jab to level change with active lead hand", "Fence exits: outside step, shoulder turn, underhook", "Flow round: two strikes, reset, then entry"]
  }
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body)
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;

    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > 250 * 1024 * 1024) {
        reject(new Error("Upload too large for this demo server"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function parseMultipart(req, body) {
  const contentType = req.headers["content-type"] || "";
  const boundary = contentType.match(/boundary=(.+)$/)?.[1];
  const fields = {};
  const files = {};

  if (!boundary) return { fields, files };

  const raw = body.toString("latin1");
  const parts = raw.split(`--${boundary}`);

  for (const part of parts) {
    if (!part.includes("Content-Disposition")) continue;

    const [headerBlock, ...bodyParts] = part.split("\r\n\r\n");
    const value = bodyParts.join("\r\n\r\n").replace(/\r\n--$/, "").replace(/\r\n$/, "");
    const name = headerBlock.match(/name="([^"]+)"/)?.[1];
    const filename = headerBlock.match(/filename="([^"]*)"/)?.[1];
    if (!name) continue;

    if (filename) {
      files[name] = {
        filename: path.basename(filename) || "training-footage.mp4",
        size: Buffer.byteLength(value, "latin1")
      };
    } else {
      fields[name] = value.trim();
    }
  }

  return { fields, files };
}

function buildAnalysis(fields, files) {
  const discipline = playbooks[fields.discipline] ? fields.discipline : "Boxing";
  const playbook = playbooks[discipline];
  const focus = fields.focus || "Overall technique";
  const skillLevel = fields.skillLevel || "Intermediate";
  const fileName = files.video?.filename || "Sample footage";
  const fileSize = files.video?.size || 0;
  const confidence = Math.min(94, Math.max(72, 80 + Math.round(fileSize / 1024 / 1024) % 10));

  return {
    id: crypto.randomUUID(),
    source: "Local analysis API",
    discipline,
    focus,
    skillLevel,
    fileName,
    confidence,
    scores: playbook.scores,
    moments: playbook.moments,
    drills: playbook.drills,
    nextIntegration: "Replace this local playbook with pose extraction plus model-generated coach notes."
  };
}

function serveFile(req, res) {
  const requestPath = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  const cleanPath = requestPath === "/" ? "/index.html" : requestPath;
  const filePath = path.normalize(path.join(root, cleanPath));

  if (!filePath.startsWith(root)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404);
      res.end("Not found");
      return;
    }

    res.writeHead(200, {
      "Content-Type": mimeTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream"
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/api/health") {
    sendJson(res, 200, { ok: true, service: "MatSense AI" });
    return;
  }

  if (req.method === "POST" && req.url === "/api/analyze") {
    try {
      const body = await readBody(req);
      const { fields, files } = parseMultipart(req, body);
      sendJson(res, 200, buildAnalysis(fields, files));
    } catch (error) {
      sendJson(res, 400, { error: error.message });
    }
    return;
  }

  if (req.method === "GET" || req.method === "HEAD") {
    serveFile(req, res);
    return;
  }

  res.writeHead(405);
  res.end("Method not allowed");
});

server.listen(port, "127.0.0.1");
